class ProductionDataSource { 
   boolean pooling = true 
   String dbCreate = "update" 
   String url = "jdbc:mysql://localhost/racetrack_prod" 
   String driverClassName = "com.mysql.jdbc.Driver" 
   String username = "prod" 
   String password = "wahoowa"
}
