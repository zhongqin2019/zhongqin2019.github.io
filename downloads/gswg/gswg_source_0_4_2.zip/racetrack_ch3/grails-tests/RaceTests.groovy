class RaceTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
