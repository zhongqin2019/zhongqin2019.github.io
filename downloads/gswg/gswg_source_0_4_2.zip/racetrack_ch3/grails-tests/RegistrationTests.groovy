class RegistrationTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
