class TestDataSource { 
   boolean pooling = true 
   String dbCreate = "update" 
   String url = "jdbc:mysql://localhost/racetrack_test" 
   String driverClassName = "com.mysql.jdbc.Driver" 
   String username = "jason" 
   String password = "" 
} 
