function warnBeforeRaceDelete() { 
     return confirm('Are you sure you want to delete this race?') 
}

function warnBeforeRegistrationDelete() { 
     return confirm('Are you sure you want to delete this registration?') 
}