class RaceControllerTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
