class UserTests extends GroovyTestCase {

	void testSomething() {
		
	}
}
